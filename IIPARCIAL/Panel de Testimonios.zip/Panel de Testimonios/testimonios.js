export const testimonios = {
    "testimonios": [
      {
        "nombre": "Carlos Sagastume",
        "mensaje": "La experiencia con la empresa fue increíble. Recomendado al 100%.",
        "fecha": "2023-12-01"
      },
      {
        "nombre": "Laura García",
        "mensaje": "Muy buen servicio, siempre atentos a los detalles.",
        "fecha": "2023-11-15"
      },
      {
        "nombre": "Pedro Ramírez",
        "mensaje": "La calidad del producto es excelente, sin duda volvería a comprar.",
        "fecha": "2023-10-25"
      }
    ]
  }
  