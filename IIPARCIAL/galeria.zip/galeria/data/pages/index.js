
export const imagenes = {
    images: [
      { src: "https://picsum.photos/id/1/300/200", alt: "Imagen 1" },
      { src: "https://picsum.photos/id/2/300/200", alt: "Imagen 2" },
      { src: "https://picsum.photos/id/3/300/200", alt: "Imagen 3" },
      { src:"https://picsum.photos/id/10/300/200", alt: "Imagen 4" },
      { src: "https://picsum.photos/id/11/300/200", alt: "Imagen 5" },
      { src: "https://picsum.photos/id/12/300/200", alt: "Imagen 6" },
      { src: "https://picsum.photos/id/20/300/200", alt: "Imagen 7" },
      { src: "https://picsum.photos/id/21/300/200", alt: "Imagen 8" },
      { src: "https://picsum.photos/id/22/300/200", alt: "Imagen 9" },
      { src: "https://picsum.photos/id/30/300/200", alt: "Imagen 10" },
      { src: "https://picsum.photos/id/31/300/200", alt: "Imagen 11" },
      { src: "https://picsum.photos/id/32/300/200", alt: "Imagen 12" },
      { src: "https://picsum.photos/id/40/300/200", alt: "Imagen 13" },
      { src: "https://picsum.photos/id/41/300/200", alt: "Imagen 14" },
      { src: "https://picsum.photos/id/42/300/200", alt: "Imagen 15" }
    ]
  };
  